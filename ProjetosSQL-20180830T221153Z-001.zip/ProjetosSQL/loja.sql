create database loja;
 use loja;

create table produtos( 
id int primary key auto_increment, 
nome varchar(50) not null, 
preco varchar(30), 
criado_em timestamp);

select *from produtos;