create database anunciosdb;
use anunciosdb;

create table anuncios(
id int primary key auto_increment,
titulo varchar(255) not null,
descricao text not null,
valor decimal(8,2),
categoria varchar(150),
autor varchar(255),
contato varchar(150),
cidade varchar(150),
estado varchar(150),
criado_em timestamp);